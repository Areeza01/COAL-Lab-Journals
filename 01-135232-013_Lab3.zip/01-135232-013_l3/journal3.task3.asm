.model small
.data
 
msgg1 db "Enter the dividend : $"
msgg2 db "Enter the divisor : $"
msgg3 db "The remainder  is : $"
msgg4 db "The quotient is : $" 
space db 10,13,"$"

dividend db ?
divisor db ?
quotient db ?
remainder db ?

.code
main:
mov ax,@data
mov ds,ax

LEA dx,msgg1
mov ah,09h
int 21h



mov ah,01h
int 21h

mov dividend,al
sub dividend,48


mov ah,09h
LEA dx,space
int 21h


LEA dx,msgg2
int 21h


mov ah,01h
int 21h

mov divisor,al
sub divisor,48


xor ax,ax
mov al,dividend
div divisor
mov quotient,al
mov remainder,ah
mov ah,09h
LEA dx,space
int 21h

mov ah,09h
LEA dx,msgg3
int 21h
mov ah,02h
mov dl,remainder
add dl,48
int 21h
mov ah,09h
LEA dx,space
int 21h

mov ah,09h
LEA dx,msgg4
int 21h

mov ah,02h
mov dl,quotient
add dl,48
int 21h
 
mov ah,4Ch
int 21h

