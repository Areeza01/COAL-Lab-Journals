.model small

.data 

v1 db 5
v2 db 2
msg1 db "The result of addition is : $"
msg2 db "The result of the subtraction is : $"
space db 10,13,"$"

.code
main:
mov ax,@data
mov ds,ax

mov cl,v1
add cl,v2
add cl,48

LEA dx,msg1

mov ah,09h
int 21h


mov dl,cl

mov ah,02h
int 21h

 
LEA dx,space
mov ah,09h
int 21h

 
LEA dx,msg2
int 21h



mov cl,v1
sub cl,v2
add cl,48

mov dl,cl
mov ah,02h
int 21h



mov ah,4Ch
int 21h

end main
