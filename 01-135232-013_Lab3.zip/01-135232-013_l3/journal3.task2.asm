.model small
.data
 
m1 db "Enter first Number : $"
m2 db "Enter second Number : $"
m3 db "The result of multiplication is : $"
space db 10,13,"$"

num1 db ?
num2 db ?

.code
main:
mov ax,@data
mov ds,ax

LEA dx,m1
mov ah,09h
int 21h


mov ah,01h
int 21h

mov num1,al
sub num1,48


mov ah,09h
LEA dx,space
int 21h


LEA dx,m2
mov ah,09h
int 21h


mov ah,01h
int 21h

mov num2,al
sub num2,48


mov ah,09h
LEA dx,space
int 21h


LEA dx,m3
mov ah,09h
int 21h


mov al,num1
mul num2

mov dl,al
add dl,48

mov ah,02h
int 21h


mov ah,4Ch
int 21h

end main
