.model small
.data

num dw 123 
numm db ?
divisor db ?
number1 db ?
number2 db ?
number3 db ?

msg db "The number is : $"

.code
main:
mov ax,@data
mov ds,ax

mov ax,num
mov divisor,100
div divisor         

mov numm,al          
mov number1,ah        

mov al,number1          
mov ah,0             
mov divisor,10
div divisor          

mov number2,al          
mov number3,ah          

mov ah,09h
lea dx,msg
int 21h
mov ah,02h
mov dl,numm
add dl,48
int 21h
mov dl,number2
add dl,48
int 21h
mov dl,number3
add dl,48
int 21h
 
mov ah,4Ch
int 21h
end main
