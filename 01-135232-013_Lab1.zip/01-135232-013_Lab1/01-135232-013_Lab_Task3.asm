.model small

.data

msg db "*" , "$"
msg1 db 0dh, 0ah, "**" , "$"
msg2 db 0dh, 0ah, "***" , "$"
msg3 db 0dh, 0ah, "****" , "$" 
msg4 db 0dh, 0ah, "*****" , "$"
.code
main:
mov ax,@data
mov ds,ax

mov dx,offset msg
mov ah,9
int 21h
  

mov dx,offset msg1  
mov ah,9
int 21h

mov dx,offset msg2  
mov ah,9
int 21h  

mov dx,offset msg3  
mov ah,9
int 21h 

mov dx,offset msg4 
mov ah,9
int 21h

mov ah,4ch
int 21h 

end main
