;Task 2

.model small

.data

msg db "Areeza" , "$"
msg1 db 0dh, 0ah, 20h,20h, "is" , "$"
msg2 db 0dh, 0ah, 20h,20h,20h,20h, "my" , "$"
msg3 db 0dh, 0ah, 20h,20h,20h,20h,20h,20h, "name" , "$"
.code
main:
mov ax,@data
mov ds,ax

mov dx,offset msg
mov ah,9
int 21h
  

mov dx,offset msg1  
mov ah,9
int 21h

mov dx,offset msg2  
mov ah,9
int 21h  

mov dx,offset msg3  
mov ah,9
int 21h

mov ah,4ch
int 21h 

end main

