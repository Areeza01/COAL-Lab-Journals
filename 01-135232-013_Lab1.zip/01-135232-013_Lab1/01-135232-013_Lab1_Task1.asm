;Task 1   

.model small

.data

msg db "Areeza Maryam" , "$"
msg1 db 0dh, 0ah, "Enrollment: 01-135232-013" , "$"
msg2 db 0dh, 0ah, "Program: BS-IT" , "$"

.code
main:
mov ax,@data
mov ds,ax

mov dx,offset msg
mov ah,9
int 21h
  

mov dx,offset msg1  
mov ah,9
int 21h

mov dx,offset msg2  
mov ah,9
int 21h

mov ah,4ch
int 21h 

end main

