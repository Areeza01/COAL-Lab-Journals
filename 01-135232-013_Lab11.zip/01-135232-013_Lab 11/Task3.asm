include 'emu8086.inc'
.model small
.stack 100h
.data
   num dw 70, 65, 55, 60, 50, 45, 35, 40, 20, 10
 
 
.code
main proc
   mov ax, @data
   mov ds, ax
 
   call bubble_sort
 
  
   print "Sorted Array: "
   mov si, 0
   mov cx, 10
 
print_array:
   mov ax, num[si]
   call PRINT_NUM    
   print " "           
   add si, 2           
   loop print_array
 
   mov ah, 4Ch
   int 21h
main endp
 
bubble_sort proc
   mov cx, 10
   dec cx
 
outer_pass:
   mov si, 0
   mov dx, cx
 
inner_compare:
   mov ax, num[si]
   cmp ax, num[si+2]
   jbe skip_swap
 
call swap_elements
 
 
skip_swap:
   add si, 2
   dec dx
   jnz inner_compare
 
   loop outer_pass
   ret
bubble_sort endp
                 
swap_elements proc
   mov bx, num[si+2]
   mov num[si], bx
   mov num[si+2], ax 
   ret
swap_elements endp                 
define_print_num
define_print_num_uns
end main
