include 'emu8086.inc'
.model small
.stack 100h
.data
    num1 dw 5
    num2 dw 10

.code
main proc
    mov ax, @data
    mov ds, ax

    print "Before swapping: "
    mov ax, num1
    call PRINT_NUM
    print " "
    mov ax, num2
    call PRINT_NUM

    call swap_vars

    printn ""
    print "After swapping: "
    mov ax, num1
    call PRINT_NUM
    print " "
    mov ax, num2
    call PRINT_NUM

    mov ah, 4Ch
    int 21h
main endp

swap_vars proc
    mov ax, num1   
    mov bx, num2      
    mov num1, bx      
    mov num2, ax      
    ret
swap_vars endp

define_print_num
define_print_num_uns
end main
