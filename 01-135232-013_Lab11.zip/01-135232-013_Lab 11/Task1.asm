include 'emu8086.inc'
.model small
.stack 100h
.data
    number dw 7

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ax, number
    call check_prime

    mov ah, 4Ch
    int 21h
main endp

check_prime proc
    mov cx, number
    shr cx, 1       
    mov bx, 2       

    cmp number, 2        
    jb not_prime

check_loop:
    cmp bx, cx      
    ja is_prime
    
    mov ax, number
    mov dx, 0
    div bx          
    cmp dx, 0       
    je not_prime
    
    inc bx
    jmp check_loop

is_prime:
    print "This is a prime number"
    ret
not_prime:
    print "This is not a prime number"
    ret
check_prime endp
end main
