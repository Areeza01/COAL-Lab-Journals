include 'emu8086.inc'
ORG 100h

SUM5 MACRO n1, n2, n3, n4, n5
    MOV AX, n1      
    ADD AX, n2      
    ADD AX, n3
    ADD AX, n4
    ADD AX, n5
    PRINT 'Sum = '
    CALL PrintNum    
    PRINTN ''        
ENDM
SUM5 10, 20, 30, 40, 50   
SUM5 15, 20, 30, 40, 50   
SUM5 10, 25, 30, 40, 50   
SUM5 10, 20, 35, 40, 50   
SUM5 10, 20, 30, 45, 50   

RET
PrintNum PROC
    MOV BX, 10
    MOV CX, 0
div_loop:
    MOV DX, 0
    DIV BX           
    PUSH DX          
    INC CX          
    CMP AX, 0
    JNE div_loop     
print_loop:
    POP DX
    ADD DL, '0'      
    MOV AH, 2
    INT 21h          
    LOOP print_loop
    RET
PrintNum ENDP

END