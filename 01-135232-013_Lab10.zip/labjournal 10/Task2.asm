include 'emu8086.inc'
ORG 100h
MulTwo MACRO
    LOCAL ask_again, not_both_zero, done
ask_again:
    PRINTN 'Enter first number (0-9):'
    MOV AH, 1       
    INT 21h
    SUB AL, '0'      
    MOV BL, AL       
    PRINTN ''

    PRINTN 'Enter second number (0-9):'
    MOV AH, 1
    INT 21h
    SUB AL, '0'      
    MOV CL, AL       
    PRINTN ''

    CMP BL, 0
    JNE not_both_zero
    CMP CL, 0
    JE done         

not_both_zero:
    MOV AL, BL       
    MOV AH, 0        
    MUL CL          

    PRINT 'Product = '
    CALL PrintNum    
    PRINTN ''
    JMP ask_again   

done:
    PRINTN 'Program ended!'
ENDM
MulTwo
RET
PrintNum PROC
    MOV BX, 10
    MOV CX, 0
div_loop:
    MOV DX, 0
    DIV BX
    PUSH DX
    INC CX
    CMP AX, 0
    JNE div_loop
print_loop:
    POP DX
    ADD DL, '0'
    MOV AH, 2
    INT 21h
    LOOP print_loop
    RET
PrintNum ENDP
END