
PrintNum MACRO num
    LOCAL divide_loop, print_loop

    MOV AX, num            
    MOV BX, 10              
    MOV CX, 0               

divide_loop:
    MOV DX, 0               
    DIV BX                  
                           
    PUSH DX                
    INC  CX                 
    CMP  AX, 0              
    JNE  divide_loop        
print_loop:
    POP  DX                
    ADD  DL, '0'            
    MOV  AH, 02h           
    INT  21h
    LOOP print_loop        
ENDM

ORG 100h
LEA DX, msg_prompt
MOV AH, 09h                 
INT 21h


MOV SI, 0                  
MOV CX, 0                   

input_loop:
    CMP CX, 3               
    JE  input_done         

    MOV AH, 08h             
    INT 21h                 

    CMP AL, 13              
    JE  input_done         

    CMP AL, '0'            
    JB  input_loop
    CMP AL, '9'             
    JA  input_loop
    MOV DL, AL
    MOV AH, 02h            
    INT 21h
    SUB AL, '0'             
    MOV AH, 0              

    PUSH AX                 
    MOV  AX, SI             
    MOV  BX, 10
    MUL  BX                 
    MOV  SI, AX             
    POP  AX                 
    ADD  SI, AX             

    INC CX                 
    JMP input_loop

input_done:
    MOV [user_num], SI      
MOV AH, 02h
MOV DL, 13                 
INT 21h
MOV DL, 10                  
INT 21h
LEA DX, msg_result
MOV AH, 09h                 
INT 21h
PrintNum [user_num]         
MOV AH, 02h
MOV DL, 13
INT 21h
MOV DL, 10
INT 21h
RET
user_num   DW 0
msg_prompt DB 'Enter a number (max 3 digits, Enter to stop early): $'
msg_result DB 'Number you entered: $'

END