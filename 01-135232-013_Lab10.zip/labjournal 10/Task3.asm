include 'emu8086.inc'
ORG 100h
PrintRow MACRO count
    LOCAL star_loop          
    MOV CX, count            
star_loop:
    PUTC '*'                 
    LOOP star_loop           
    PRINTN ''                
ENDM

PrintRow 1
PrintRow 3
PrintRow 5
PrintRow 7
PrintRow 9
PrintRow 11

RET
END