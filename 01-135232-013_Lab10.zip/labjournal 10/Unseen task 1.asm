include 'emu8086.inc'
PrintTriangle MACRO rows
    LOCAL row_loop, star_loop, row_done

    MOV BH, rows    
    MOV DH, 1        

row_loop:
    CMP DH, BH       
    JG  row_done

    MOV CL, DH       
                     
star_loop:
    PUTC '*'         
    DEC CL
    JNZ star_loop    

    PRINTN ''       
    INC DH           
    JMP row_loop

row_done:
ENDM
ORG 100h
PRINT 'Enter number of rows (1-9): '
MOV AH, 1
INT 21h              
SUB AL, '0'          
MOV [num_rows], AL   
PRINTN ''
PRINTN ''
keep_printing:

    PrintTriangle [num_rows]   
    PRINTN ''                  
    MOV AH, 01h
    INT 16h
    JZ  keep_printing          
    MOV AH, 00h
    INT 16h                    

    CMP AL, 13                
    JNE keep_printing          
PRINTN ''
PRINTN 'Enter pressed. Goodbye!'
RET
num_rows DB 0

END