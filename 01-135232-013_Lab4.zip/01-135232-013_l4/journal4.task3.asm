.model small
.data

number1 db ?
number2 db ?
number3 db ? 
hundred db 100
tens db 10
res db ?
temp db ?
space db 10,13,"$"


msg1 db "Enter the value of first number: $"
msg2 db "Enter the value of second number: $"
msg3 db "Enter the value of third number: $"
msg4 db "The number is : $"
.code
main:

mov ax,@data
mov ds,ax 
mov ah,09h
LEA dx,msg1
int 21h
LEA dx,space
int 21h
xor ax,ax
mov ah,01h
int 21h
mov number1,al
sub number1,48 
mov ah,09h
LEA dx,space
int 21h
mov ah,09h
LEA dx,msg2
int 21h
LEA dx,space
int 21h
xor ax,ax
mov ah,01h
int 21h
mov number2,al
sub number2,48
mov ah,09h
LEA dx,space
int 21h

mov ah,09h
LEA dx,msg3
int 21h
LEA dx,space
int 21h
xor ax,ax
mov ah,01h
int 21h
mov number3,al
sub number3,48
mov ah,09h
LEA dx,space
int 21h 

xor ax,ax
mov al,number1
mul hundred
mov res,al

xor ax,ax
mov al,number2
mul tens
add res,al

mov al,number2
add res,al

mov ax,ax
mov al,res
div hundred
mov number1,al
mov temp,ah
xor ax,ax
mov al,temp
div tens
mov number2,al
mov number3,ah
add number1,48
add number2,48
add number3,48
mov ah,09h
LEA dx,msg4
int 21h
mov ah,02h
mov dl,number1
int 21h
mov dl,number2
int 21h
mov dl,number3
int 21h
mov ah,4Ch
int 21h
end main

ret




