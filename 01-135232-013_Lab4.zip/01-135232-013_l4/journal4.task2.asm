.model small
.data

variable1 db -2
variable2 db -2
divisor db -2

msg1 db "The result of -2 x -2:  $"
msg2 db "The result of 4/-2:  $"

.code
main:

mov ax,@data
mov ds,ax 

LEA dx,msg1
mov ah,09h
int 21h
mov ax,0
mov al,variable1
IMUL variable2
mov bl,al  
IDIV divisor
mov bl,al  
end main

