.model small
.code
main proc
    mov cx, 5         
    mov bl, 5       
outerloop:
    push  cx  
    mov ch, 0
    mov cl, 5
    sub cl, bl       
spaceloop:
    cmp cl, 0
    je printnumber
    mov dl, ' '
    mov ah, 2
    int 21h
    dec cl
    jmp spaceloop
printnumber:
    mov ch, 0
    mov cl, bl
    add cl, bl
    dec cl           
innerloop:
    mov dl, bl
    add dl, 48       
    mov ah, 2
    int 21h
    dec cl
    jnz innerloop
    mov dl, 13
    mov ah, 2
    int 21h
    mov dl, 10
    int 21h
    pop cx           
    dec bl           
    loop outerloop
    mov ah, 4ch
    int 21h

main endp
end main
