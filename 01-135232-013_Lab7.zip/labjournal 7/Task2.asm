.model small
.code
main proc
    mov cx, 4         
    mov bl, 1         
outerloop:
    push cx
     mov al, 4
    sub al, bl         
    mov cl, al
spaceloop:
    cmp cl, 0
    je numbers
    mov dl, ' '
    mov ah, 2
    int 21h
    dec cl
    jmp spaceloop
numbers:  
    mov cl, bl
    mov dl, bl
descloop:
    add dl, 48
    mov ah, 2
    int 21h
    sub dl, 48
    dec dl
    dec cl
    jnz descloop
    mov cl, bl
    dec cl            
    mov dl, 2
ascloop:
    cmp cl, 0
    je newline
    add dl, 48
    mov ah, 2
    int 21h
    sub dl, 48
    inc dl
    dec cl
    jmp ascloop
newline:
    mov dl, 13
    mov ah, 2
    int 21h
    mov dl, 10
    int 21h
    pop cx
    inc bl
    loop outerloop
    mov ah, 4ch
    int 21h
main endp
end main
