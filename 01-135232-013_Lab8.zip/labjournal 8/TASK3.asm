.model small
.data
    array      db 5 dup(?)
    msg_input  db "Enter a digit (0-9): $"
    msg_sorted db 13,10,"Descending Order: $"
    msg_space  db " $"
.code
    mov ax, @data
    mov ds, ax
    mov cx, 5
    mov si, 0
input_loop:
    mov ah, 09h
    lea dx, msg_input
    int 21h

    mov ah, 01h
    int 21h            

    sub al, 30h         
    mov array[si], al   
    mov ah, 02h
    mov dl, 13
    int 21h
    mov dl, 10
    int 21h

    inc si
    loop input_loop
    mov bx, 4          
outer_loop:
    mov cx, bx         
    mov si, 0          
inner_loop:
    mov al, array[si]       
    mov ah, array[si+1]     

    cmp al, ah          
    jae no_swap       
    mov array[si],   ah
    mov array[si+1], al
no_swap:
    inc si
    loop inner_loop
    dec bx
    jnz outer_loop    
    mov ah, 09h
    lea dx, msg_sorted
    int 21h
    mov cx, 5
    mov si, 0
print_loop:
    mov al, array[si]
    add al, 30h         
    mov ah, 02h
    mov dl, al
    int 21h             
    mov ah, 09h
    lea dx, msg_space
    int 21h
    inc si
    loop print_loop
    mov ah, 4ch
    int 21h
end
