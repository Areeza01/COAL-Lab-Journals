.model small
.data
    array   db 10 dup(?)      
    even_count db 0            
    odd_count  db 0            

    msg_input  db "Enter a number (0-9): $"
    msg_even   db 13,10,"Even Count: $"
    msg_odd    db 13,10,"Odd Count : $"
    msg_more_even db 13,10,"Even numbers are more.$"
    msg_more_odd  db 13,10,"Odd numbers are more.$"
    msg_equal     db 13,10,"Count of both is equal.$"
.code
    mov ax, @data
    mov ds, ax
    mov cx, 10         
    mov si, 0         

input_loop:
    mov ah, 09h
    lea dx, msg_input
    int 21h                                     
    mov ah, 01h
    int 21h             

    sub al, 30h         
    mov array[si], al   

    inc si
    loop input_loop
    mov cx, 10
    mov si, 0

count_loop:
    mov al, array[si]   
    and al, 01h         
                        
    jnz is_odd

is_even:
    inc even_count
    jmp next

is_odd:
    inc odd_count

next:
    inc si
    loop count_loop
    mov ah, 09h
    lea dx, msg_even
    int 21h

    mov al, even_count
    add al, 30h         
    mov ah, 02h
    mov dl, al
    int 21h

    ; --- Print Odd Count ---
    mov ah, 09h
    lea dx, msg_odd
    int 21h

    mov al, odd_count
    add al, 30h
    mov ah, 02h
    mov dl, al
    int 21h
    mov al, even_count
    cmp al, odd_count
    ja  even_more
    jb  odd_more

    mov ah, 09h
    lea dx, msg_equal
    int 21h
    jmp done

even_more:
    mov ah, 09h
    lea dx, msg_more_even
    int 21h
    jmp done

odd_more:
    mov ah, 09h
    lea dx, msg_more_odd
    int 21h

done:
    mov ah, 4ch
    int 21h

end
