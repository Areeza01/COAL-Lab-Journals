.model small
.data
    msg_input  db "Enter a single digit (0-9): $"
    msg_less   db 13,10,"Number is less than 5.$"
    msg_div    db 13,10,"Even. After dividing by 2: $"
    msg_mul    db 13,10,"Odd. After multiplying by 2: $"
.code
    mov ax, @data
    mov ds, ax
    mov ah, 09h
    lea dx, msg_input
    int 21h
    mov ah, 01h
    int 21h             
    sub al, 30h        
    mov bl, al          
    cmp bl, 5
    jl  less_than_5
    mov al, bl
    and al, 01h         
    jnz odd_case
even_case:
    mov ah, 09h
    lea dx, msg_div
    int 21h
    mov al, bl
    mov ah, 00h
    mov cl, 02h
    div cl             
    add al, 30h
    mov ah, 02h
    mov dl, al
    int 21h
    jmp done
odd_case:
    mov ah, 09h
    lea dx, msg_mul
    int 21h
    mov al, bl
    mov ah, 00h
    mov cl, 02h
    mul cl            
    mov bl, al  
    cmp bl, 10
    jl  one_digit     
    mov al, bl
    mov ah, 00h
    mov cl, 10
    div cl      
    push ax
    add al, 30h
    mov ah, 02h
    mov dl, al
    int 21h
    pop ax
    add ah, 30h
    mov dl, ah
    mov ah, 02h
    int 21h
    jmp done

one_digit:
    add bl, 30h
    mov ah, 02h
    mov dl, bl
    int 21h
    jmp done
less_than_5:
    mov ah, 09h
    lea dx, msg_less
    int 21h
done:
    mov ah, 4ch
    int 21h
end
