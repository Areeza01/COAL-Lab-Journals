.model small
.data
    msg_prompt db "Enter a number (1-7): $"
    msg_mon    db 13,10,"Monday$"
    msg_tue    db 13,10,"Tuesday$"
    msg_wed    db 13,10,"Wednesday$"
    msg_thu    db 13,10,"Thursday$"
    msg_fri    db 13,10,"Friday$"
    msg_sat    db 13,10,"Saturday$"
    msg_sun    db 13,10,"Sunday$"
    msg_inv    db 13,10,"Invalid Input$"
.code
    mov ax, @data
    mov ds, ax
    mov ah, 09h
    lea dx, msg_prompt
    int 21h
    mov ah, 01h
    int 21h             
    sub al, 30h       
    cmp al, 0
    je  invalid
    cmp al, 7
    ja  invalid
    cmp al, 1
    je  day1
    cmp al, 2
    je  day2
    cmp al, 3
    je  day3
    cmp al, 4
    je  day4
    cmp al, 5
    je  day5
    cmp al, 6
    je  day6
    cmp al, 7
    je  day7
invalid:
    mov ah, 09h
    lea dx, msg_inv
    int 21h
    jmp done
day1:
    mov ah, 09h
    lea dx, msg_mon
    int 21h
    jmp done
day2:
    mov ah, 09h
    lea dx, msg_tue
    int 21h
    jmp done
day3:
    mov ah, 09h
    lea dx, msg_wed
    int 21h
    jmp done
day4:
    mov ah, 09h
    lea dx, msg_thu
    int 21h
    jmp done
day5:
    mov ah, 09h
    lea dx, msg_fri
    int 21h
    jmp done
day6:
    mov ah, 09h
    lea dx, msg_sat
    int 21h
    jmp done
day7:
    mov ah, 09h
    lea dx, msg_sun
    int 21h
done:
    mov ah, 4ch
    int 21h
end
