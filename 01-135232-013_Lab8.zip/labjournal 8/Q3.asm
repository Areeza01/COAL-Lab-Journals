.model small
.data
    msg_input1  db "Enter a single digit (0-9): $"
    msg_input2  db 13,10,"Enter another digit (0-9): $"
    msg_sum     db 13,10,"Sum of both numbers: $"
    msg_mul     db 13,10,"Number is odd. After multiplying by 2: $"

.code
    mov ax, @data
    mov ds, ax
    mov ah, 09h
    lea dx, msg_input1
    int 21h

    mov ah, 01h
    int 21h
    sub al, 30h         
    mov bl, al         
    mov al, bl
    and al, 01h
    jnz not_divisible   
divisible:
    mov ah, 09h
    lea dx, msg_input2
    int 21h
    mov ah, 01h
    int 21h
    sub al, 30h         
    mov cl, al      
    mov al, bl
    add al, cl   
    mov bh, al     
    mov ah, 09h
    lea dx, msg_sum
    int 21h
    cmp bh, 10
    jl  sum_one_digit
    mov al, bh
    mov ah, 00h
    mov cl, 10
    div cl 
    push ax
    add al, 30h
    mov ah, 02h
    mov dl, al
    int 21h  
    pop ax
    add ah, 30h
    mov dl, ah
    mov ah, 02h
    int 21h             
    jmp done
sum_one_digit:
    add bh, 30h
    mov ah, 02h
    mov dl, bh
    int 21h
    jmp done
not_divisible:
    mov ah, 09h
    lea dx, msg_mul
    int 21h

    mov al, bl
    mov ah, 00h
    mov cl, 02h
    mul cl              

    mov bh, al         
    cmp bh, 10
    jl  mul_one_digit
    mov al, bh
    mov ah, 00h
    mov cl, 10
    div cl       
    push ax
    add al, 30h
    mov ah, 02h
    mov dl, al
    int 21h
    pop ax
    add ah, 30h
    mov dl, ah
    mov ah, 02h
    int 21h
    jmp done
mul_one_digit:
    add bh, 30h
    mov ah, 02h
    mov dl, bh
    int 21h
done:
    mov ah, 4ch
    int 21h
end
