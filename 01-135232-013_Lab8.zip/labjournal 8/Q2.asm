.model small
.data
    msg_prompt db 13,10,"Enter a digit (0-9) or press Enter to quit: $"
    msg_A      db 13,10,"Grade: A$"
    msg_B      db 13,10,"Grade: B$"
    msg_C      db 13,10,"Grade: C$"
    msg_F      db 13,10,"Grade: F$"
    msg_inv    db 13,10,"Invalid Input$"
.code
    mov ax, @data
    mov ds, ax
ask_again:
    mov ah, 09h
    lea dx, msg_prompt
    int 21h
    mov ah, 01h
    int 21h             
    cmp al, 13
    je  quit
    sub al, 30h       
    cmp al, 10
    ja  invalid   
    cmp al, 8
    jae grade_A         

    cmp al, 5
    jae grade_B         

    cmp al, 3
    jae grade_C        
grade_F:
    mov ah, 09h
    lea dx, msg_F
    int 21h
    jmp ask_again

grade_A:
    mov ah, 09h
    lea dx, msg_A
    int 21h
    jmp ask_again

grade_B:
    mov ah, 09h
    lea dx, msg_B
    int 21h
    jmp ask_again

grade_C:
    mov ah, 09h
    lea dx, msg_C
    int 21h
    jmp ask_again

invalid:
    mov ah, 09h
    lea dx, msg_inv
    int 21h
    jmp ask_again

quit:
    mov ah, 4ch
    int 21h
end
