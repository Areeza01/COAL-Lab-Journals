.org 100h
.code
mov cl,26
mov dl,122

L1:
mov ah,2
int 21h
dec dl
loop L1