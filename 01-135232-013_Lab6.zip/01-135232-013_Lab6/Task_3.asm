.org 100h
.data

.code

mov bl,0
mov cx,10
L1:
mov ah,1
int 21h
cmp al,bl
JG swap
jmp skip
swap:
xchg al,bl
skip:
loop L1

add dl,48
mov dl,bl
mov ah,2
int 21h

