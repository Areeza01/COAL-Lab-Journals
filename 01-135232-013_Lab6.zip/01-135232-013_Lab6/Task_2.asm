
.model small
.org 100h     

.code 
main:
mov cx,9
L1:
mov ax,cx
mov bl, 2
div bl

cmp ah,1
jne escape

mov dl,cl
add dl,30h
mov ah,02h
int 21h

escape:
dec cx
jne L1

mov ah,4ch
int 21h

end main
