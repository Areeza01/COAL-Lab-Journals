.model small
.data
msgg1 db "Enter the number you want to check even or odd for $" 
msgg2 db "The number is even $"
msgg3 db "The number is odd $" 
space db 10,13,'$'
variable db ?

.code
main:
mov ax,@data
mov ds,ax
mov ah,09h
LEA dx,msgg1
int 21h
mov ah,01h
int 21h 
mov ah,09h
LEA dx,space
int 21h

sub al,48
mov variable,al

xor ax,ax
mov al,variable

mov variable,2
div variable

cmp ah,0
je IfEqual

LEA dx,msgg3
mov ah,09h
int 21h

mov ah,4Ch
int 21h

IfEqual:
          
LEA dx,msgg2
mov ah,09h
int 21h

mov ah,4ch
int 21h
end main


