.model small
.stack 100h
.data
arr dw 1,2,3,4,5,6,7,8,9,10
msg1 db "Original: $"
msg2 db 0Dh,0Ah,"Reversed: $"

.code
main proc
    mov ax, @data
    mov ds, ax

    mov dx, offset msg1
    mov ah, 09h
    int 21h

    mov cx, 10
    mov si, 0

print_original:
    mov ax, arr[si]
    call print_num
    add si, 2
    loop print_original

    mov cx, 10
    mov si, 0

push_loop:
    mov ax, arr[si]
    push ax
    add si, 2
    loop push_loop

    mov cx, 10
    mov si, 0

pop_loop:
    pop ax
    mov arr[si], ax
    add si, 2
    loop pop_loop

    mov dx, offset msg2
    mov ah, 09h
    int 21h

    mov cx, 10
    mov si, 0

print_reverse:
    mov ax, arr[si]
    call print_num
    add si, 2
    loop print_reverse

    mov ah, 4ch
    int 21h

main endp

print_num proc
    mov bx, 10
    mov dx, 0
    div bx         

    push dx        

    cmp ax, 0
    je one_digit

    add al, '0'     
    mov dl, al
    mov ah, 02h
    int 21h

one_digit:
    pop dx          
    add dl, '0'     
    mov ah, 02h
    int 21h


    mov dl, ' '
    mov ah, 02h
    int 21h

    ret
print_num endp
end main















