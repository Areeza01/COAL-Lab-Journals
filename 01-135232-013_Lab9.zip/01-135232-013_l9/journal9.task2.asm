.model small
.stack 100h
.data
    arr db 10 dup(?)
    msg1  db "Enter 10 digits: $"
    msg2 db 13, 10, "Result: $"

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ah, 09h
    lea dx, msg1
    int 21h

    mov cx, 10
    mov si, 0

input_loop:
    mov ah, 01h
    int 21h
    sub al, '0'
    mov arr[si], al
    inc si
    loop input_loop

    mov cx, 10
    mov si, 0
    mov bx, 0

push_even:
    mov al, arr[si]
    mov ah, 0
    mov dl, 2
    div dl

    cmp ah, 0
    jne skip

    mov al, arr[si]
    mov ah, 0
    push ax
    inc bx

skip:
    inc si
    loop push_even

    mov ah, 09h
    lea dx, msg2
    int 21h

pop_loop:
    cmp bx, 0
    je end_prog

    pop ax
    dec bx
    
    cmp al, 6
    jge pop_loop

    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h

    mov dl, ' '
    int 21h

    jmp pop_loop

end_prog:
    mov ah, 4ch
    int 21h

main endp
end main

