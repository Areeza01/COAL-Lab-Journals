.model small
.data
msg db ?  
msg1 db "Enter a character","$"
newline db 10,13,"$"
.code
main proc

mov ax,@data
mov ds,ax  


mov ah,02h
mov dl, 'A' 
int 21h 

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg1
mov ah,09h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov ah,01h
int 21h

mov msg,al

mov ah, 4Ch
int 21h



main endp
end main

