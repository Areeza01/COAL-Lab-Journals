.model small


.data
msg1 db "Enter first digit: $"
msg2 db "Enter second digit: $"
msg3 db "Sum = $"

.code
main proc
    mov ax, @data
    mov ds, ax

    
    mov ah, 09h
    mov dx, offset msg1
    int 21h

   
    mov ah, 01h
    int 21h
    sub al, 48        
    mov bl, al          
 mov ah, 02h
    mov dl, 0Dh
    int 21h
    mov dl, 0Ah
    int 21h

  mov ah, 09h
    mov dx, offset msg2
    int 21h

 
    mov ah, 01h
    int 21h
    sub al, 48          

  
    add al, bl
    add al, 48          
    mov cl, al        


    mov ah, 02h
    mov dl, 0Dh
    int 21h
    mov dl, 0Ah
    int 21h

    
    mov ah, 09h
    mov dx, offset msg3
    int 21h

    
    mov ah, 02h
    mov dl, cl
    int 21h

  
    mov ah, 4Ch
    int 21h

main endp
end main