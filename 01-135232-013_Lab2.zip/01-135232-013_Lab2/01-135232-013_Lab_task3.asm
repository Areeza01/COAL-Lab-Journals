.model small
.data   

msg db "2 x 1 = " , "$"
r1 db 2   

msg2 db "2 x 2 = " , "$"
r2 db 4  

msg3 db "2 x 3 = " , "$"
r3 db 6  

msg4 db "2 x 4 = " , "$"
r4 db 8  

msg5 db "2 x 5 = " , "$"
r5 db 1
r6 db 0 
msg6 db "2 x 6 = " , "$"
msg7 db "2 x 7 = " , "$"
msg8 db "2 x 8 = " , "$"
msg9 db "2 x 9 = " , "$"
msg10 db "2 x 10 = " , "$"
newline db 10,13,"$"

.code   

main:   
mov ax,@data
mov ds,ax

mov dx,offset msg
mov ah,09h
int 21h

mov dl,r1
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg2
mov ah,09h
int 21h 

mov dl,r2
add dl,48
mov ah, 02h
int 21h  

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg3
mov ah,09h
int 21h 

mov dl,r3
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg4
mov ah,09h
int 21h 

mov dl,r4
add dl,48
mov ah, 02h
int 21h   

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg5
mov ah,09h
int 21h 

mov dl,r5
add dl,48
mov ah, 02h
int 21h
mov dl,r6
add dl,48
mov ah, 02h
int 21h


mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg6
mov ah,09h
int 21h 

mov dl,r5
add dl,48
mov ah, 02h
int 21h
mov dl,r1
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg7
mov ah,09h
int 21h 

mov dl,r5
add dl,48
mov ah, 02h
int 21h
mov dl,r2
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg8
mov ah,09h
int 21h 

mov dl,r5
add dl,48
mov ah, 02h
int 21h
mov dl,r3
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg9
mov ah,09h
int 21h 

mov dl,r5
add dl,48
mov ah, 02h
int 21h
mov dl,r4
add dl,48
mov ah, 02h
int 21h

mov dx, offset newline
mov ah,09h
int 21h

mov dx,offset msg10
mov ah,09h
int 21h 

mov dl,r1
add dl,48
mov ah, 02h
int 21h
mov dl,r6
add dl,48
mov ah, 02h
int 21h

mov ah,4Ch
int 21h
end main