org 100h
jmp start

source1: dw 1, 2, 3, 4
dest1:   dw 0, 0, 0, 0

source2: dw 5, 6, 7, 8
dest2:   dw 0, 0, 0, 0

msg1 db 'Destination Array 1: $'
msg2 db 13,10,'Destination Array 2: $'

copyArray:

 push bp
 mov bp, sp

 push ax
 push bx
 push cx
 push si
 push di

 mov si, [bp+8]
 mov di, [bp+6]
 mov cx, [bp+4]

 shl cx, 1

 mov bx, 0

mainloop:

 mov ax, [si+bx]
 mov [di+bx], ax

 add bx, 2

 cmp bx, cx
 jne mainloop

 pop di
 pop si
 pop cx
 pop bx
 pop ax

 pop bp

ret 6


printArray:

 push bp
 mov bp, sp

 push ax
 push bx
 push cx
 push si

 mov si, [bp+6]
 mov cx, [bp+4]

 mov bx, 0

printloop:

 mov ax, [si+bx]

 add ax, 48

 mov dl, al
 mov ah, 02h
 int 21h

 mov dl, ' '
 mov ah, 02h
 int 21h

 add bx, 2

 loop printloop

 pop si
 pop cx
 pop bx
 pop ax

 pop bp

ret 4



start:

 mov ax, source1
 push ax

 mov ax, dest1
 push ax

 mov ax, 4
 push ax

 call copyArray

 mov ax, source2
 push ax

 mov ax, dest2
 push ax

 mov ax, 4
 push ax

 call copyArray


 lea dx, msg1
 mov ah, 09h
 int 21h

 mov ax, dest1
 push ax

 mov ax, 4
 push ax

 call printArray

 lea dx, msg2
 mov ah, 09h
 int 21h

 mov ax, dest2
 push ax

 mov ax, 4
 push ax

 call printArray



mov ax, 4c00h
int 21h