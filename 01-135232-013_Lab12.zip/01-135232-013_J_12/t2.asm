org 100h
jmp start

data:  dw 1, 2, 3, 2, 5
data2: dw 4, 4, 1, 4, 7

msg1 db 'Replacement Count 1: $'
msg2 db 13,10,'Replacement Count 2: $'

replaceVal:

 push bp
 mov bp, sp
 sub sp, 2

 push bx
 push cx
 push si

 mov bx, [bp+8]
 mov cx, [bp+6]

 mov word [bp-2], 0

 shl cx, 1

 mov si, 0

mainloop:

 mov ax, [bx+si]

 cmp ax, [bp+4]
 jne noswap

 mov word [bx+si], 0
 add word [bp-2], 1

noswap:

 add si, 2

 cmp si, cx
 jne mainloop

 mov ax, [bp-2]

 pop si
 pop cx
 pop bx

 mov sp, bp
 pop bp

ret 6

printNum:

 push ax
 push dx

 add ax, 48

 mov dl, al
 mov ah, 02h
 int 21h

 pop dx
 pop ax

ret

start:

 mov ax, data
 push ax

 mov ax, 5
 push ax

 mov ax, 2
 push ax

 call replaceVal

 mov bx, ax

 lea dx, msg1
 mov ah, 09h
 int 21h

 mov ax, bx
 call printNum

 mov ax, data2
 push ax

 mov ax, 5
 push ax

 mov ax, 4
 push ax

 call replaceVal

 mov bx, ax

 lea dx, msg2
 mov ah, 09h
 int 21h

 mov ax, bx
 call printNum

mov ax, 4c00h
int 21h